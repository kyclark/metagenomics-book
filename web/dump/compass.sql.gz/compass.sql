-- MySQL dump 10.13  Distrib 5.6.34, for Linux (x86_64)
--
-- Host: localhost    Database: compass
-- ------------------------------------------------------
-- Server version	5.6.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `case_worker`
--

DROP TABLE IF EXISTS `case_worker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `case_worker` (
  `case_worker_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`case_worker_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_worker`
--

LOCK TABLES `case_worker` WRITE;
/*!40000 ALTER TABLE `case_worker` DISABLE KEYS */;
INSERT INTO `case_worker` VALUES (1,'Tate Wynn'),(2,'Cruz Knox'),(3,'Sybill Hudson'),(4,'Matthew Powers'),(5,'Ryder Pratt'),(6,'Hayley Guy'),(7,'Vernon Eaton'),(8,'Shannon Floyd'),(9,'Travis Bass'),(10,'Kirby Jackson'),(11,'Autumn Ayers');
/*!40000 ALTER TABLE `case_worker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client` (
  `client_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `case_worker_id` int(10) unsigned DEFAULT NULL,
  `case_num` int(10) unsigned NOT NULL DEFAULT '0',
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `aka` varchar(100) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `sex` enum('U','M','F') DEFAULT 'U',
  `ethnicity` varchar(50) DEFAULT NULL,
  `race` varchar(50) DEFAULT NULL,
  `is_homeless` enum('Y','N') DEFAULT 'N',
  `is_disabled` enum('Y','N') DEFAULT 'N',
  `is_employed` enum('Y','N') DEFAULT 'N',
  `marital_status` varchar(100) DEFAULT NULL,
  `original_date_service` date DEFAULT NULL,
  `address_street` varchar(100) DEFAULT NULL,
  `address_city` varchar(100) DEFAULT NULL,
  `address_state` varchar(100) DEFAULT NULL,
  `address_zip` varchar(100) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `notes` text,
  PRIMARY KEY (`client_id`),
  KEY `last_name` (`last_name`),
  KEY `case_worker_id` (`case_worker_id`),
  CONSTRAINT `client_ibfk_1` FOREIGN KEY (`case_worker_id`) REFERENCES `case_worker` (`case_worker_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES (1,4,1,'Ignatius','Sims',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 141, 1383 Lacinia Rd.','Gillette','Wyoming','42772',NULL,NULL),(2,7,2,'Bruno','Page',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 440, 1132 Diam Road','North Las Vegas','NV','94395',NULL,NULL),(3,5,3,'Kasper','Charles',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #589-1265 Mollis Ave','Boise','ID','27516',NULL,NULL),(4,3,4,'Nora','Ingram',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 904, 3196 Eu Av.','Portland','Maine','53654',NULL,NULL),(5,2,5,'Lareina','Baird',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #975-2493 Eu, St.','Auburn','ME','58289',NULL,NULL),(6,7,6,'Graiden','Knowles',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #966-2804 Adipiscing Avenue','Cincinnati','Ohio','02786',NULL,NULL),(7,3,7,'Denise','Jacobs',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'4079 A, Ave','Tampa','FL','64863',NULL,NULL),(8,4,8,'Joel','Faulkner',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #159-1536 Lacinia St.','Seattle','WA','71291',NULL,NULL),(9,1,9,'Octavia','Tanner',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'662-3956 Vel Street','Phoenix','Arizona','32062',NULL,NULL),(10,8,10,'Ivana','Beasley',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'340 Amet Rd.','Helena','Montana','82900',NULL,NULL),(11,11,11,'Harding','Harrell',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #539-3639 Consequat Avenue','Portland','OR','35303',NULL,NULL),(12,6,12,'Jakeem','Bernard',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 737, 2187 Et St.','Kearney','NE','96588',NULL,NULL),(13,2,13,'Xavier','Barry',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #920-9032 Vestibulum Av.','Topeka','KS','16432',NULL,NULL),(14,1,14,'Branden','Hess',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #425-7722 Donec St.','Grand Island','Nebraska','30169',NULL,NULL),(15,4,15,'Alfreda','Moody',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'775 A Rd.','Orlando','FL','77735',NULL,NULL),(16,7,16,'Colorado','Riggs',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #693-988 Diam Av.','Jacksonville','FL','27677',NULL,NULL),(17,8,17,'Susan','Bryan',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #915-2528 Iaculis Rd.','Auburn','ME','52318',NULL,NULL),(18,4,18,'Cynthia','Mcbride',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 482, 369 Nullam Street','Las Vegas','NV','86871',NULL,NULL),(19,11,19,'Anthony','Petty',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 732, 8074 In Road','Kenosha','Wisconsin','14354',NULL,NULL),(20,4,20,'Eagan','Thornton',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 170, 545 Neque Rd.','Pittsburgh','PA','41922',NULL,NULL),(21,7,21,'Kalia','Conway',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 190, 3147 Tempor Av.','Kenosha','WI','19318',NULL,NULL),(22,8,22,'Keegan','Donaldson',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'644-2861 Velit Avenue','Sterling Heights','Michigan','08412',NULL,NULL),(23,3,23,'Ayanna','Lang',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'929-7624 Cursus. Avenue','Biloxi','MS','31971',NULL,NULL),(24,8,24,'Phelan','Cabrera',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'633-5763 Fringilla Rd.','Richmond','VA','53885',NULL,NULL),(25,8,25,'Igor','Avila',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #965-2996 Faucibus Rd.','Duluth','MN','25669',NULL,NULL),(26,10,26,'Quon','Wiggins',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'2510 Elementum Ave','San Antonio','TX','16535',NULL,NULL),(27,2,27,'Uriah','Taylor',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #866-9629 Imperdiet Road','Grand Rapids','Michigan','37022',NULL,NULL),(28,4,28,'Blair','Heath',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 550, 5980 Dolor Av.','Chandler','AZ','00611',NULL,NULL),(29,1,29,'Sybil','Manning',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #116-2116 Molestie Rd.','Springfield','MO','15026',NULL,NULL),(30,3,30,'Hannah','Stephens',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 747, 7627 Non, Rd.','Houston','TX','83927',NULL,NULL),(31,5,31,'Velma','May',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'622-7915 Sed Av.','Little Rock','AR','32820',NULL,NULL),(32,1,32,'Xaviera','Curry',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 227, 7253 Suspendisse St.','Erie','Pennsylvania','16089',NULL,NULL),(33,3,33,'Christian','Duffy',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 331, 5336 Donec Street','Kenosha','WI','95818',NULL,NULL),(34,5,34,'Patience','Cooke',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'474-3393 Vitae Ave','Tucson','AZ','74050',NULL,NULL),(35,9,35,'Daryl','Norman',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 607, 5607 Netus Road','Fort Worth','Texas','17631',NULL,NULL),(36,9,36,'Harding','Chaney',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'1801 Phasellus St.','Jacksonville','FL','69911',NULL,NULL),(37,3,37,'Amaya','Howell',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'534-1795 Scelerisque Av.','Rock Springs','WY','17575',NULL,NULL),(38,3,38,'Jael','Noble',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'8027 Dis St.','Great Falls','Montana','69796',NULL,NULL),(39,1,39,'Gillian','Stewart',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #899-3926 Dolor Rd.','Covington','Kentucky','31236',NULL,NULL),(40,10,40,'Abbot','Sutton',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 649, 671 Elementum, Road','Waterbury','CT','50180',NULL,NULL),(41,3,41,'Kieran','Evans',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'8953 Ipsum. St.','Tuscaloosa','AL','46699',NULL,NULL),(42,3,42,'Eric','Glass',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 340, 6979 Nibh. Av.','Warren','Michigan','31068',NULL,NULL),(43,11,43,'Ignacia','Donaldson',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #954-926 Erat St.','Rock Springs','WY','32910',NULL,NULL),(44,5,44,'Cullen','Sweet',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 122, 7287 Donec Ave','Kansas City','Missouri','03498',NULL,NULL),(45,6,45,'Grace','Mcconnell',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'553 Aenean Road','Columbus','GA','46692',NULL,NULL),(46,8,46,'Jescie','Bray',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'3670 Eu, St.','Pittsburgh','Pennsylvania','06906',NULL,NULL),(47,6,47,'Lance','Bradley',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'3276 Ornare Road','Atlanta','GA','10094',NULL,NULL),(48,8,48,'Justina','Waller',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'698-8821 Velit Street','Bridgeport','CT','21900',NULL,NULL),(49,8,49,'Flynn','Henderson',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'588-3029 Eleifend Avenue','Lincoln','Nebraska','70169',NULL,NULL),(50,5,50,'Ashely','Prince',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'3713 Consequat Av.','Metairie','LA','96228',NULL,NULL),(51,8,51,'Shoshana','Jennings',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'1138 Ligula Rd.','Newark','Delaware','22747',NULL,NULL),(52,8,52,'Ray','Wiggins',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #904-645 Tempor, Rd.','Aurora','CO','37887',NULL,NULL),(53,2,53,'Stacy','Davis',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #539-3950 Morbi Rd.','Nashville','Tennessee','04345',NULL,NULL),(54,3,54,'Cadman','Boyd',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'381-7762 Venenatis Road','Lowell','Massachusetts','47889',NULL,NULL),(55,4,55,'Ignatius','York',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'802-9149 Risus Road','Frankfort','KY','53835',NULL,NULL),(56,10,56,'Shelley','Singleton',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 417, 3209 Ridiculus St.','New Orleans','LA','61491',NULL,NULL),(57,5,57,'Skyler','Burris',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'554-1661 Phasellus Ave','Springfield','Illinois','02355',NULL,NULL),(58,8,58,'Jeanette','Howell',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #540-8793 Consequat, Rd.','Fayetteville','AR','95890',NULL,NULL),(59,4,59,'Leilani','Brown',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #931-6027 Et Av.','Savannah','Georgia','23967',NULL,NULL),(60,2,60,'Hollee','Bray',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'807-8770 Pharetra Ave','Louisville','KY','41307',NULL,NULL),(61,3,61,'Suki','Deleon',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'5832 Et, St.','Bear','DE','39639',NULL,NULL),(62,1,62,'Kamal','Trujillo',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #758-8030 Ac Av.','Fresno','CA','74398',NULL,NULL),(63,2,63,'Hashim','Castaneda',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #963-5322 Ipsum Av.','Erie','PA','76983',NULL,NULL),(64,9,64,'Fay','Kramer',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'230-5745 Donec Rd.','Juneau','Alaska','10355',NULL,NULL),(65,6,65,'Xena','Gill',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'9418 Dictum St.','Topeka','Kansas','07463',NULL,NULL),(66,9,66,'Renee','Graham',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'646-8385 Vestibulum Ave','Indianapolis','Indiana','53613',NULL,NULL),(67,1,67,'Quemby','Phillips',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'6099 Et, Road','Gresham','Oregon','49266',NULL,NULL),(68,7,68,'Hammett','Garza',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 244, 8771 Ut, Ave','Kapolei','Hawaii','16994',NULL,NULL),(69,2,69,'Rhiannon','Bridges',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 401, 4050 Iaculis Street','Independence','MO','47548',NULL,NULL),(70,10,70,'Kirestin','Church',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'246-3262 Litora Rd.','Colorado Springs','CO','74290',NULL,NULL),(71,7,71,'Lavinia','Barker',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'294-200 Cubilia Road','Bellevue','NE','60410',NULL,NULL),(72,5,72,'Amity','Mullins',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 377, 771 Consectetuer Av.','Eugene','Oregon','89293',NULL,NULL),(73,5,73,'Blaine','Castaneda',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'3779 Convallis Ave','Waterbury','CT','00956',NULL,NULL),(74,11,74,'Tatyana','Estrada',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #146-9869 Vel St.','Baltimore','Maryland','70720',NULL,NULL),(75,11,75,'Daphne','Thornton',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 263, 3220 Mattis Avenue','Philadelphia','PA','53013',NULL,NULL),(76,2,76,'Shelly','Adams',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'517-2449 Vestibulum Avenue','Helena','Montana','63429',NULL,NULL),(77,9,77,'Lane','Manning',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 862, 8385 Phasellus Street','Rockville','Maryland','94938',NULL,NULL),(78,2,78,'Lucas','Sloan',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'7142 Amet, Rd.','Nashville','Tennessee','20248',NULL,NULL),(79,7,79,'Sopoline','Bennett',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 725, 5568 Vitae St.','Green Bay','Wisconsin','37917',NULL,NULL),(80,9,80,'Kendall','Buckner',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'8410 Eu St.','Tulsa','Oklahoma','03592',NULL,NULL),(81,6,81,'Colton','Guerra',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 114, 4845 A, Rd.','Great Falls','Montana','40037',NULL,NULL),(82,7,82,'Katell','White',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 392, 9027 Mauris, Rd.','Pocatello','ID','61142',NULL,NULL),(83,2,83,'Jessica','Davis',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #483-5662 Auctor Rd.','Atlanta','GA','21197',NULL,NULL),(84,9,84,'Phillip','Blankenship',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'905-4590 Ac, Avenue','Jefferson City','Missouri','24760',NULL,NULL),(85,3,85,'Rudyard','Noel',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 659, 6526 A Rd.','Kearney','NE','88358',NULL,NULL),(86,3,86,'Astra','Hampton',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'341-6485 Aliquam Road','Eugene','Oregon','85322',NULL,NULL),(87,11,87,'Hilel','Mcfarland',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #134-7730 Fringilla Rd.','Birmingham','Alabama','79889',NULL,NULL),(88,5,88,'Kelsie','Potts',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'820 Vehicula Av.','Gulfport','MS','37152',NULL,NULL),(89,3,89,'Nicholas','Ortiz',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'156-5843 Ut, Street','Augusta','GA','03934',NULL,NULL),(90,11,90,'Joelle','Conner',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #928-5526 Mattis. Rd.','Bridgeport','Connecticut','04314',NULL,NULL),(91,2,91,'Devin','Fletcher',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'613-2382 Sed Avenue','Flint','Michigan','05794',NULL,NULL),(92,11,92,'Wynter','Casey',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 489, 977 Id Ave','Reading','PA','89794',NULL,NULL),(93,1,93,'Scarlett','Macdonald',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'P.O. Box 202, 7173 Sapien, Street','Duluth','MN','91429',NULL,NULL),(94,4,94,'Erasmus','Eaton',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #943-4667 Nulla Avenue','Wyoming','Wyoming','88260',NULL,NULL),(95,7,95,'Alisa','Coffey',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'533 Porttitor Street','Richmond','Virginia','30816',NULL,NULL),(96,6,96,'Hyacinth','Ryan',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #912-7040 Venenatis Avenue','Chandler','AZ','54389',NULL,NULL),(97,4,97,'Amal','Robertson',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #579-7362 Vel, Rd.','Racine','Wisconsin','50422',NULL,NULL),(98,8,98,'Quon','Henson',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'495-525 Montes, Avenue','Cheyenne','WY','24341',NULL,NULL),(99,8,99,'Jenna','Stone',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'Ap #677-8355 Proin Rd.','Knoxville','TN','87717',NULL,NULL),(100,8,100,'Lester','Wiley',NULL,NULL,'U',NULL,NULL,'N','N','N',NULL,NULL,'6005 Bibendum Rd.','Green Bay','Wisconsin','10337',NULL,NULL);
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_phone`
--

DROP TABLE IF EXISTS `client_phone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_phone` (
  `client_phone_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`client_phone_id`),
  KEY `client_id` (`client_id`),
  CONSTRAINT `client_phone_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `client` (`client_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_phone`
--

LOCK TABLES `client_phone` WRITE;
/*!40000 ALTER TABLE `client_phone` DISABLE KEYS */;
INSERT INTO `client_phone` VALUES (1,1,'(828) 132-7810',NULL),(2,2,'(868) 434-6424',NULL),(3,3,'(966) 108-0804',NULL),(4,4,'(109) 538-8021',NULL),(5,5,'(346) 783-2693',NULL),(6,6,'(432) 650-6964',NULL),(7,7,'(677) 495-7960',NULL),(8,8,'(882) 120-5997',NULL),(9,9,'(357) 209-0425',NULL),(10,10,'(478) 960-1017',NULL),(11,11,'(918) 543-4933',NULL),(12,12,'(774) 952-4442',NULL),(13,13,'(547) 370-0111',NULL),(14,14,'(148) 646-0846',NULL),(15,15,'(312) 264-0835',NULL),(16,16,'(301) 447-3544',NULL),(17,17,'(701) 600-2969',NULL),(18,18,'(308) 759-3008',NULL),(19,19,'(317) 733-9679',NULL),(20,20,'(309) 468-8762',NULL),(21,21,'(959) 434-5975',NULL),(22,22,'(760) 898-8208',NULL),(23,23,'(429) 626-7928',NULL),(24,24,'(197) 297-2782',NULL),(25,25,'(395) 693-3951',NULL),(26,26,'(824) 655-6486',NULL),(27,27,'(100) 604-1140',NULL),(28,28,'(463) 981-3024',NULL),(29,29,'(654) 910-5384',NULL),(30,30,'(401) 620-1776',NULL),(31,31,'(780) 815-2584',NULL),(32,32,'(482) 535-1042',NULL),(33,33,'(413) 442-1710',NULL),(34,34,'(842) 152-9137',NULL),(35,35,'(357) 236-0982',NULL),(36,36,'(715) 505-8514',NULL),(37,37,'(676) 707-1528',NULL),(38,38,'(281) 949-6347',NULL),(39,39,'(844) 993-8399',NULL),(40,40,'(813) 971-8971',NULL),(41,41,'(608) 349-4210',NULL),(42,42,'(623) 862-3509',NULL),(43,43,'(133) 549-7372',NULL),(44,44,'(293) 469-9012',NULL),(45,45,'(969) 691-6880',NULL),(46,46,'(535) 223-5987',NULL),(47,47,'(965) 121-4612',NULL),(48,48,'(232) 359-0161',NULL),(49,49,'(501) 570-6069',NULL),(50,50,'(468) 187-6101',NULL),(51,51,'(281) 341-6613',NULL),(52,52,'(601) 981-9564',NULL),(53,53,'(373) 212-1777',NULL),(54,54,'(984) 177-8112',NULL),(55,55,'(743) 802-3753',NULL),(56,56,'(338) 646-9763',NULL),(57,57,'(450) 413-7708',NULL),(58,58,'(748) 975-0447',NULL),(59,59,'(555) 394-4981',NULL),(60,60,'(694) 201-5229',NULL),(61,61,'(580) 245-9131',NULL),(62,62,'(668) 231-1614',NULL),(63,63,'(260) 515-6150',NULL),(64,64,'(206) 420-5092',NULL),(65,65,'(218) 446-1709',NULL),(66,66,'(777) 299-1548',NULL),(67,67,'(484) 705-4251',NULL),(68,68,'(420) 648-0173',NULL),(69,69,'(126) 732-5091',NULL),(70,70,'(461) 142-5559',NULL),(71,71,'(725) 755-1394',NULL),(72,72,'(938) 806-6693',NULL),(73,73,'(438) 115-2051',NULL),(74,74,'(730) 994-7302',NULL),(75,75,'(223) 704-1266',NULL),(76,76,'(558) 454-8960',NULL),(77,77,'(826) 202-7282',NULL),(78,78,'(557) 959-3500',NULL),(79,79,'(154) 173-6462',NULL),(80,80,'(245) 286-4267',NULL),(81,81,'(397) 948-2359',NULL),(82,82,'(470) 258-6240',NULL),(83,83,'(972) 706-0894',NULL),(84,84,'(467) 181-7813',NULL),(85,85,'(635) 534-3257',NULL),(86,86,'(142) 108-5295',NULL),(87,87,'(439) 305-2734',NULL),(88,88,'(915) 901-3027',NULL),(89,89,'(214) 587-0300',NULL),(90,90,'(558) 208-7021',NULL),(91,91,'(501) 216-8091',NULL),(92,92,'(484) 595-3154',NULL),(93,93,'(744) 880-7044',NULL),(94,94,'(269) 757-8309',NULL),(95,95,'(476) 216-7623',NULL),(96,96,'(670) 623-1426',NULL),(97,97,'(894) 538-0669',NULL),(98,98,'(398) 261-3703',NULL),(99,99,'(910) 612-5233',NULL),(100,100,'(197) 451-3672',NULL);
/*!40000 ALTER TABLE `client_phone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dependent`
--

DROP TABLE IF EXISTS `dependent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dependent` (
  `dependent_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `sex` enum('U','M','F') DEFAULT 'U',
  `relationship` varchar(100) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `ethnicity` varchar(50) DEFAULT NULL,
  `race` varchar(50) DEFAULT NULL,
  `is_disabled` enum('Y','N') DEFAULT 'N',
  PRIMARY KEY (`dependent_id`),
  KEY `client_id` (`client_id`),
  CONSTRAINT `dependent_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `client` (`client_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dependent`
--

LOCK TABLES `dependent` WRITE;
/*!40000 ALTER TABLE `dependent` DISABLE KEYS */;
INSERT INTO `dependent` VALUES (1,16,'Susan','Lindsey','U',NULL,NULL,NULL,NULL,'N'),(2,23,'Hedda','Delgado','U',NULL,NULL,NULL,NULL,'N'),(3,99,'Georgia','Cooper','U',NULL,NULL,NULL,NULL,'N'),(4,68,'Beatrice','Osborne','U',NULL,NULL,NULL,NULL,'N'),(5,24,'Jelani','Hanson','U',NULL,NULL,NULL,NULL,'N'),(6,86,'Angelica','Mosley','U',NULL,NULL,NULL,NULL,'N'),(7,16,'Elijah','Mcfadden','U',NULL,NULL,NULL,NULL,'N'),(8,82,'Kiayada','Cardenas','U',NULL,NULL,NULL,NULL,'N'),(9,47,'Zephania','Albert','U',NULL,NULL,NULL,NULL,'N'),(10,32,'Gay','Conrad','U',NULL,NULL,NULL,NULL,'N'),(11,24,'Keegan','Sloan','U',NULL,NULL,NULL,NULL,'N'),(12,75,'Nina','Zamora','U',NULL,NULL,NULL,NULL,'N'),(13,13,'Josiah','Carney','U',NULL,NULL,NULL,NULL,'N'),(14,4,'Cadman','Alexander','U',NULL,NULL,NULL,NULL,'N'),(15,66,'Chaim','Barnett','U',NULL,NULL,NULL,NULL,'N'),(16,73,'Remedios','Strong','U',NULL,NULL,NULL,NULL,'N'),(17,6,'Jordan','Barry','U',NULL,NULL,NULL,NULL,'N'),(18,75,'Wanda','Estrada','U',NULL,NULL,NULL,NULL,'N'),(19,34,'Simone','Brewer','U',NULL,NULL,NULL,NULL,'N'),(20,25,'Audrey','Koch','U',NULL,NULL,NULL,NULL,'N'),(21,93,'Lee','Monroe','U',NULL,NULL,NULL,NULL,'N'),(22,48,'Denton','Bryan','U',NULL,NULL,NULL,NULL,'N'),(23,33,'Zeus','Mathis','U',NULL,NULL,NULL,NULL,'N'),(24,86,'Leroy','Maddox','U',NULL,NULL,NULL,NULL,'N'),(25,24,'Davis','Chambers','U',NULL,NULL,NULL,NULL,'N'),(26,70,'Kasper','Lancaster','U',NULL,NULL,NULL,NULL,'N'),(27,81,'Brooke','Vincent','U',NULL,NULL,NULL,NULL,'N'),(28,63,'Fleur','Sims','U',NULL,NULL,NULL,NULL,'N'),(29,44,'Norman','Gibbs','U',NULL,NULL,NULL,NULL,'N'),(30,66,'Thane','York','U',NULL,NULL,NULL,NULL,'N'),(31,38,'Jael','Welch','U',NULL,NULL,NULL,NULL,'N'),(32,83,'Kitra','Morgan','U',NULL,NULL,NULL,NULL,'N'),(33,26,'Troy','Conway','U',NULL,NULL,NULL,NULL,'N'),(34,99,'Tarik','Guy','U',NULL,NULL,NULL,NULL,'N'),(35,54,'Fletcher','Mays','U',NULL,NULL,NULL,NULL,'N'),(36,100,'Gavin','Malone','U',NULL,NULL,NULL,NULL,'N'),(37,82,'Regan','Workman','U',NULL,NULL,NULL,NULL,'N'),(38,16,'Caleb','Vincent','U',NULL,NULL,NULL,NULL,'N'),(39,89,'Mercedes','Bryan','U',NULL,NULL,NULL,NULL,'N'),(40,79,'Fuller','Aguirre','U',NULL,NULL,NULL,NULL,'N'),(41,66,'Ferdinand','Mays','U',NULL,NULL,NULL,NULL,'N'),(42,74,'Maia','Price','U',NULL,NULL,NULL,NULL,'N'),(43,1,'Thaddeus','Chase','U',NULL,NULL,NULL,NULL,'N'),(44,47,'Uma','Dale','U',NULL,NULL,NULL,NULL,'N'),(45,75,'Leila','Schroeder','U',NULL,NULL,NULL,NULL,'N'),(46,30,'Shellie','Cunningham','U',NULL,NULL,NULL,NULL,'N'),(47,99,'Jared','Mills','U',NULL,NULL,NULL,NULL,'N'),(48,95,'Philip','Spears','U',NULL,NULL,NULL,NULL,'N'),(49,99,'Angelica','Robles','U',NULL,NULL,NULL,NULL,'N'),(50,69,'Nyssa','Tyler','U',NULL,NULL,NULL,NULL,'N'),(51,74,'Miranda','Sexton','U',NULL,NULL,NULL,NULL,'N'),(52,36,'Rhonda','Barr','U',NULL,NULL,NULL,NULL,'N'),(53,1,'Aristotle','Gallagher','U',NULL,NULL,NULL,NULL,'N'),(54,70,'Chase','Lara','U',NULL,NULL,NULL,NULL,'N'),(55,61,'Howard','Odom','U',NULL,NULL,NULL,NULL,'N'),(56,62,'Caryn','Andrews','U',NULL,NULL,NULL,NULL,'N'),(57,98,'Tanner','Vaughan','U',NULL,NULL,NULL,NULL,'N'),(58,62,'Cooper','Hubbard','U',NULL,NULL,NULL,NULL,'N'),(59,42,'Magee','Gill','U',NULL,NULL,NULL,NULL,'N'),(60,87,'Imogene','Hall','U',NULL,NULL,NULL,NULL,'N'),(61,70,'Phillip','Palmer','U',NULL,NULL,NULL,NULL,'N'),(62,24,'Amanda','Wiley','U',NULL,NULL,NULL,NULL,'N'),(63,20,'Scarlett','Parks','U',NULL,NULL,NULL,NULL,'N'),(64,4,'Kelsie','Lamb','U',NULL,NULL,NULL,NULL,'N'),(65,64,'Gannon','Bradley','U',NULL,NULL,NULL,NULL,'N'),(66,70,'Avye','Banks','U',NULL,NULL,NULL,NULL,'N'),(67,21,'Curran','Albert','U',NULL,NULL,NULL,NULL,'N'),(68,99,'Alvin','Ruiz','U',NULL,NULL,NULL,NULL,'N'),(69,36,'Freya','Hamilton','U',NULL,NULL,NULL,NULL,'N'),(70,59,'Russell','Chan','U',NULL,NULL,NULL,NULL,'N'),(71,91,'Melyssa','Moody','U',NULL,NULL,NULL,NULL,'N'),(72,64,'Kieran','Pena','U',NULL,NULL,NULL,NULL,'N'),(73,40,'Stella','Weiss','U',NULL,NULL,NULL,NULL,'N'),(74,19,'Raven','Miles','U',NULL,NULL,NULL,NULL,'N'),(75,90,'Preston','Love','U',NULL,NULL,NULL,NULL,'N'),(76,26,'Hiram','Whitley','U',NULL,NULL,NULL,NULL,'N'),(77,16,'Declan','Lindsay','U',NULL,NULL,NULL,NULL,'N'),(78,5,'Tanek','Macias','U',NULL,NULL,NULL,NULL,'N'),(79,100,'Addison','Gallagher','U',NULL,NULL,NULL,NULL,'N'),(80,18,'Courtney','Schwartz','U',NULL,NULL,NULL,NULL,'N'),(81,46,'Acton','Maynard','U',NULL,NULL,NULL,NULL,'N'),(82,6,'Sonya','Santana','U',NULL,NULL,NULL,NULL,'N'),(83,61,'Gail','Mcpherson','U',NULL,NULL,NULL,NULL,'N'),(84,5,'Jesse','Morris','U',NULL,NULL,NULL,NULL,'N'),(85,38,'Rudyard','Edwards','U',NULL,NULL,NULL,NULL,'N'),(86,14,'John','Sandoval','U',NULL,NULL,NULL,NULL,'N'),(87,58,'Joan','Aguilar','U',NULL,NULL,NULL,NULL,'N'),(88,17,'Jade','Morton','U',NULL,NULL,NULL,NULL,'N'),(89,74,'Jaime','Tucker','U',NULL,NULL,NULL,NULL,'N'),(90,17,'Keith','Bradley','U',NULL,NULL,NULL,NULL,'N'),(91,12,'Melvin','Hoffman','U',NULL,NULL,NULL,NULL,'N'),(92,33,'Germaine','Greene','U',NULL,NULL,NULL,NULL,'N'),(93,43,'Carly','Carver','U',NULL,NULL,NULL,NULL,'N'),(94,65,'Charlotte','King','U',NULL,NULL,NULL,NULL,'N'),(95,7,'Kiona','Mckee','U',NULL,NULL,NULL,NULL,'N'),(96,83,'Cade','Richardson','U',NULL,NULL,NULL,NULL,'N'),(97,20,'Wanda','Sanders','U',NULL,NULL,NULL,NULL,'N'),(98,77,'Jermaine','Burch','U',NULL,NULL,NULL,NULL,'N'),(99,27,'Xena','Woodard','U',NULL,NULL,NULL,NULL,'N'),(100,12,'Chelsea','Simon','U',NULL,NULL,NULL,NULL,'N');
/*!40000 ALTER TABLE `dependent` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-10-27 15:45:37
